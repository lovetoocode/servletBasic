package blogs.constant;

public class Constants {
	public static final String registrationTable = "registrations";
	public static final String blogTable = "blogs";
	public static final String BLOG_IMAGE_UPLOAD_DIRECTORY = "/WEB-INF/images/blogImages/";
}
